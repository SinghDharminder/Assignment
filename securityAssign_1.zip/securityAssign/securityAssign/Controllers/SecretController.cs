﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace securityAssign.Controllers
{
    [Authorize]
    public class SecretController : Controller
    {
        // GET: SecretController
        public ActionResult Index()
        {
            return View();
        }

        // GET: SecretController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SecretController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SecretController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SecretController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SecretController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SecretController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SecretController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
